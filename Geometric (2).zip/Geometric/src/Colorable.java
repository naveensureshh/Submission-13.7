//Colorable class and Interface
public interface Colorable {
	
	String howToColor();
}
